/* global QUnit */

sap.ui.require(["zcursoecapp1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
